$('#about--open-button').click(function () {
    $('.about--container').toggleClass('open');
});